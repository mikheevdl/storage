import $ from 'jquery';
// import Dropdown from '../dropdown/dropdown';

export default class FormHelper {
  static formatOutput(formData) {
    Object.keys(formData)
      .forEach((item) => {
        const dataItem = formData[item];
        dataItem.value = String(dataItem.value).trim();
        if ($(`[name="${dataItem.name}"]`).hasClass('js-numeric-input')) {
          dataItem.value = dataItem.value.replace(/\s+/g, '');
        }
      });
    return formData;
  }

  static setHiddenValue(name, value, form) {
    let el = form.find(`[name="${name}"]`);
    if (el.length) {
      el.val(value);
    } else {
      el = document.createElement('input');
      el.type = 'hidden';
      el.name = name;
      el.value = value;
      form[0].appendChild(el);
    }
  }

  static setAttribute(name, value, form) {
    const el = form.find(`[name="${name}"]`);
    if (el.length) {
      $(el).attr(value, 'true');
    }
    inputs.forEach((elem) => elem.stateChange());
  }

  static showInputError(name, errorMessage, formValidator) {
    const errorObject = {};
    Object.assign(errorObject, { [name]: errorMessage });
    formValidator.showErrors(errorObject);
  }

  static collectStepData(self) {
    const formData = [];
    const step = $(self.steps.getCurrent());
    const inputs = step.find('input[name]');
    const textareas = step.find('textarea[name]');
    const selects = step.find('select[name]');

    function addData(el) {
      formData.push({
        name: $(el)
          .attr('name'),
        value: $(el)
          .val(),
      });
    }

    inputs.each((index, el) => {
      if (($(el)
        .attr('type') === 'checkbox') || ($(el)
        .attr('type') === 'radio')) {
        if ($(el)
          .prop('checked')) {
          addData(el);
        }
      } else {
        addData(el);
      }
    });
    textareas.each((index, el) => {
      addData(el);
    });
    selects.each((index, el) => {
      const $options = el.querySelectorAll('option[selected="selected"]');
      if ($options.length === 1) {
        formData.push({
          name: $(el).attr('name'),
          value: $options.length ? $options[0].value : '',
        });
      } else {
        addData(el);
      }
    });
    const $formIdBlock = $('#form_id');
    if ($formIdBlock.length) {
      addData($formIdBlock);
    }
    return formData;
  }

  static prepareFormData(fields, data) {
    Array.from(fields).forEach((el, i) => {
      switch (el.nodeName.toLowerCase()) {
        case 'input':
          break;
        case 'select':
          const $options = el.querySelectorAll('option[selected="selected"]');
          const { name } = el;
          const value = $options.length ? $options[0].value : '';
          const item = data.filter((item) => item.name === name)[0];
          if ($options.length === 1 && item) {
            if (item.value !== value) {
              item.value = value;
            }
          }
          break;
        case 'textarea':
          break;
        default:
      }
    });
    return data;
  }

  static setGetHandler() {
    return (form) => {
      document.location.href = `${form.getAttribute('action')}?partner=bcs-bank&operation=${form.querySelector('.radio__field:checked')
        .id
        .match(/buy|sell/g)}&amount=${form.querySelector('.js-course-input')
        .value
        .replace(' ', '')}&currency=${form.querySelector('.js-course-field .js-title').innerText}`;
    };
  }

  static setPostHandler(self) {
    return (form) => {
      self.formSubmit(form);
      return false;
    };
  }

  static setStepPostHandler(self) {
    function send(step, form, selfInner, full) {
      if (step.hasClass('js-send-form')) {
        selfInner.formSubmit(form, step.data('send-url'), () => {
          FormHelper.setStepFront(selfInner);
        }, !full);
      } else {
        FormHelper.setStepFront(selfInner);
      }
    }

    return (form) => {
      let step = $(self.steps.getCurrent());
      if (self.steps.isLast()) {
        if (step.hasClass('js-send-validate-form')) {
          self.formSubmit(form, step.data('send-validate-url'), () => {
            self.formSubmit(form);
          }, true);
        } else {
          self.formSubmit(form);
        }
      } else {
        step = $(self.steps.getCurrent());
        if (step.hasClass('js-sms-step')) {
          // логика для новых "универсальных" форм
          if ($(form).attr('data-form') === 'universal') {
            const inputList = [];
            $(form).find('input, select, textarea').each((num, currentInput) => {
              if ($(currentInput).attr('name') !== undefined) {
                if ($(currentInput).attr('name').length > 0) {
                  inputList.push($(currentInput).attr('name'));
                }
              }
            });
            self.smsCodeForm.sendPhone(inputList, 'question_phone', (responseData) => {
              if (responseData.smsrequired === false) {
                FormHelper.setStepFront(self);
              } else {
                $(form).find('#profileguid').val(responseData.profileguid);
              }
            }, () => {
              FormHelper.setStepBack(self);
            });
          } else {
            // логика для всех остальных "старых" форм
            self.smsCodeForm.sendPhone(['question_phone', 'form_id', 'bid_user_name'], 'question_phone', () => {}, () => {
              FormHelper.setStepBack(self);
            });
          }
        }
        if (step.hasClass('js-send-validate-form')) {
          self.formSubmit(form, step.data('send-validate-url'), () => {
            send(step, form, self);
          }, true);
        } else {
          send(step, form, self, true);
        }
        // доработка для универсальной формы(шаг с полями для доставки)
        if (step.hasClass('js-get-slots')) {
          const urlSlots = step[0].dataset.sendLot;
          const city = $('form[data-form="universal"]').find('.js-city-select');
          const formDataSlots = new FormData();
          formDataSlots.append($(city).attr('name'), $(city).val());
          $.ajax({
            method: 'POST',
            type: 'POST',
            url: urlSlots,
            dataType: 'json',
            contentType: false,
            processData: false,
            data: formDataSlots,
            success: (data) => {
              console.log('Глобальные списки', global.dropdowns);
              const dateSelect = global.dropdowns.delivery_date_select;
              dateSelect.updateData(data.delivery.courier);
              const timeSelect = global.dropdowns.delivery_time_select; // аттрибут data-id
              timeSelect.updateData(data.delivery.courier[0].items);
              // Необходимо для назначения одного обработчика
              let checkHander = false;
              $.each($._data(dateSelect.$select, 'events'), (i, event) => {
                $.each(event, (j, h) => {
                  if (h.handler === 'change') {
                    checkHander = true;
                  }
                });
              });
              if (!checkHander) {
                dateSelect.$select.on('change', (e) => {
                  if (data.delivery) {
                    const timeData = data.delivery.courier.filter((item) => item.value === dateSelect.$select.val())[0].items;
                    timeSelect.updateData(timeData);
                  }
                });
              }
            },
            error: (data) => {
              console.log('error');
            },
          });
        }
      }
      // забирает значение поля и передает его в другое поле на любом из шагов формы
      const givesField = $(step).find('[data-reception]');
      $(givesField).each((i, e) => {
        // console.log(i, e);
      });
    };
  }

  static setStepsCount(self) {
    self.form.closest('.js-form')
      .find('.js-step-informer-all')
      .text(self.steps.getCount());
  }

  static setStepBack(self) {
    self.form.closest('.js-form')
      .find('.js-step-informer')
      .text(self.steps.prevStep() + 1);
  }

  static setStepFront(self) {
    console.log(self);
    self.form.closest('.js-form')
      .find('.js-step-informer')
      .text(self.steps.nextStep() + 1);
  }

  static showErrorModal() {
    $('.js-products-error')
      .modal({
        showClose: false,
      });
  }
}
