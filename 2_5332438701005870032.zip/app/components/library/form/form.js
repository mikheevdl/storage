import $ from 'jquery';
import 'jquery-validation';
import 'suggestions-jquery';
import Validator from './validator';
import StepForm from '../step-form/step-form';
import SmsForm from '../../modules/sms-code-form/sms-code';
import PlaceForm from '../../modules/form-place/form-place';
import CheckboxHide from '../checkbox-hide/checkbox-hide';
import Radio from '../radio/radio';
import FormHelper from './formHelper';
import TransferForm from './transferForm';
import DeliveryWidget from '../../modules/delivery-widget/delivery-widget';

require('formdata-polyfill');

module.exports = (elem) => {
  class Form {
    constructor(selector) {
      this.form = $(selector);
      this.steps = null;
      this.smsCodeForm = null;
      this.stepClass = 'js-step';
      this.skip_step = this.form.closest('.js-form')
      .find('#skip_step');
      this.msgSucess = this.form.closest('.js-form')
        .find('.js-form-success');
      this.msgError = this.form.closest('.js-form')
        .find('.js-form-error');
      this.formType = this.form.closest('.js-form')
        .data('form');
      this.validator = Validator(this.form);
      this.initServices();
      this.validateForm();
      this.events();

      this.transferForm = new TransferForm();
      this.transferForm.blockEvents.call(this);
    }

    initServices() {
      if (sessionStorage.getItem('input_bid_select_job_year') !== null || sessionStorage.getItem('select_bid_select_job_year') !== null) {
        console.log('%cУдаление значений сессии полей стажа', 'background-color: red; color: white; padding: 2px 4px;');
        sessionStorage.removeItem('input_bid_select_job_year');
        sessionStorage.removeItem('select_bid_select_job_year');
      }

      // if ($('[name="select_bid_select_job_year"] option:selected')) {
      //   const selectedJob = $('select[name="select_bid_select_job_year"] option:selected').val();
      //   const selectedInput = $('select[name="input_bid_select_job_year"]').val();
      //   console.log('SELECTED AND INPUT JOB YEAR ON FORM INIT', selectedJob, selectedInput);
      //   sessionStorage.setItem('input_bid_select_job_year', selectedInput);
      //   sessionStorage.setItem('select_bid_select_job_year', selectedJob);
      // }

      if (this.form.find(`.${this.stepClass}`).length) {
        this.steps = new StepForm({
          selector: this.stepClass,
          activeClass: 'state_active',
          skip_step: this.skip_step,
        }, this.form[0]);
        FormHelper.setStepsCount(this);
      }

      if (this.form.find(`.${this.stepClass}`).length) {
        this.steps = new StepForm({
          selector: this.stepClass,
          activeClass: 'state_active',
        }, this.form[0]);
        FormHelper.setStepsCount(this);
      }

      if (this.form.find('.js-sms-code-form').length) {
        this.smsCodeForm = SmsForm('.js-sms-code-form');
      }

      if (this.form.find('.js-place-to-live').length) {
        this.placeToLive = new PlaceForm('.js-place-to-live');
      }

      if (this.form.find('.js-checkbox-hidden').length) {
        this.showCheckbox = new CheckboxHide('.js-checkbox-hidden');
      }

      if (this.form.find('.js-radio-hidden').length) {
        this.showRadioBlock = new Radio('.js-radio-hidden');
      }
    }

    events() {
      if (this.steps) {
        this.form.find('.js-prev-step')
          .on('click', (e) => {
            e.preventDefault();
            this.steps.prevStep();
          });
        this.form.find('.js-step-backward')
          .on('click', () => {
            this.form.closest('.js-form')
              .find('.js-step-informer')
              .text(this.steps.prevStep(() => {
                if ($(this.steps.getCurrent())
                  .find('.js-sms-code-form').length) {
                  FormHelper.setStepBack(this);
                }
              }) + 1);
          });
      }
    }

    validateForm() {
      this.formValidator = this.validator.validateForm(this.getSubmitHundler());
    }

    getSubmitHundler() {
      const formTypeHandler = (this.formType === 'fix-course') ? FormHelper.setGetHandler() : FormHelper.setPostHandler(this);
      return this.steps ? FormHelper.setStepPostHandler(this) : formTypeHandler;
    }

    formSubmit(form, url, callback, sendStep) {
      $(form).addClass('state_loading');
      // let formDataObject = FormHelper.formatOutput(sendStep ? FormHelper.collectStepData(this) : $(form).serializeArray());
      const formDataObject = FormHelper.formatOutput(sendStep ? FormHelper.collectStepData(this) : FormHelper.prepareFormData(form.elements, $(form).serializeArray()));
      // console.log('FORM_SERIALIZE', $(form).serializeArray());
      console.log('FORM_DATA_OBJECT', formDataObject);
      const formData = new FormData();
      formDataObject.forEach((el) => {
        if (el.name === 'input_bid_select_job_year' && sessionStorage.getItem('input_bid_select_job_year') !== null) {
          // console.log('%cСравнение значений полей стажа', 'background-color: yellow; color: black; padding: 2px 4px;');
          // console.log('Текущее значение поля input: %c%s', 'color: yellow;', el.value);
          // console.log('Текущее значение сессии поля input: %c%s', 'color: yellow;', sessionStorage.getItem('input_bid_select_job_year'));
          global.log.push({
            yearData: 'input',
            yearValue: el.value,
            yearSession: sessionStorage.getItem('input_bid_select_job_year'),
          });
          // formData.set(el.name, sessionStorage.getItem('input_bid_select_city'));
        } else if (el.name === 'select_bid_select_job_year' && sessionStorage.getItem('select_bid_select_job_year') !== null) {
          // console.log('Текущее значение поля select: %c%s', 'color: yellow;', el.value);
          // console.log('Текущее значение сессии поля select: %c%s', 'color: yellow;', sessionStorage.getItem('select_bid_select_job_year'));
          global.log.push({
            yearData: 'select',
            yearValue: el.value,
            yearSession: sessionStorage.getItem('select_bid_select_job_year'),
          });
          // formData.set(el.name, sessionStorage.getItem('select_bid_select_city'));
        }
        formData.append(el.name, el.value);
      });

      if ($(form).find('.js-dropzone').length) {
        formDataObject.file = [];
        $(form).find('.file-input')[0].dropzone.files.forEach((el) => {
          if (el.status === 'queued') {
            formData.append('file[]', el);
          }
        });
      }

      if (global.log.length) {
        formData.set('form_log', JSON.stringify(global.log));
      }
      console.log(formDataObject, skip_step.value);
      $.ajax({
        method: 'POST',
        type: 'POST',
        url: (typeof url !== 'undefined') ? url : form.getAttribute('action'),
        dataType: 'json',
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: (xhr, settings) => {
          const today = new Date();
        },
        success: (data) => {
          $(form).removeClass('state_loading');
          this.processResult(url, form, data, callback);
        },
        error: () => {
          if (!url) {
            $(form).removeClass('state_loading');
            FormHelper.showErrorModal();
          }
        },
      });
    }

    processResult(url, form, data, callback) {
      const self = this;

      function showSmsError() {
        FormHelper.showInputError('sms_code', data.error, this.formValidator);
      }

      function showSuccessModal() {
        self.addPixelMetric(form, data);
        $('.js-products-success')
          .on($.modal.AFTER_CLOSE, () => {
            form.reset();
            if (this.steps) {
              this.form.closest('.js-form')
                .find('.js-step-informer')
                .text(this.steps.tofFirstStep() + 1);
            }
          })
          .modal({
            showClose: false,
          });
      }

      function showInputErrors() {
        Object.keys(data.errors)
          .forEach((item) => {
            const dataItem = data.errors[item];
            const itemValue = Array.isArray(dataItem) ? String(dataItem.join(','))
              .replace(new RegExp(',', 'g'), ', ') : dataItem;
            FormHelper.showInputError(item, itemValue, this.formValidator);
          });
      }

      function setHiddenFields() {
        Object.keys(data.set_hidden_value)
          .forEach((key) => {
            const value = data.set_hidden_value[key];
            FormHelper.setHiddenValue(key, value, this.form);
          });
      }

      function setSkipStep() {
            const value = data.skip_steps[0];
            console.log({value});
            FormHelper.setHiddenValue("skip_step", value, this.form);
      }

      function setAttributes() {
        Object.keys(data.set_attributes)
          .forEach((key) => {
            const value = data.set_attributes[key];
            FormHelper.setAttribute(key, value, this.form);
          });
      }

      if ($('.js-delivery-widget').length) {
        if (!($('.js-delivery-location').find('.js-input-field').val().length)) {
          $('.js-delivery-location').find('.js-input-field').val($('.js-city-select').val());
          $('.js-delivery-location').addClass('state_filled').removeClass('state_init');
        }
        if (typeof data.delivery !== 'undefined') {
          if (!global.deliveryWidget) {
            global.deliveryWidget = new DeliveryWidget(data.delivery);
          } else {
            global.deliveryWidget.reInitView();
          }
        }
      }
      if ($('[data-reception]')) {
        const receptionField = $('[data-reception]');
        $(receptionField).each((i, el) => {
          const receptionAttribute = $(el).attr('data-reception');
          const givesAttribute = $(`[data-gives="${receptionAttribute}"]`).find('.js-input').val();
          $(el).addClass('state_filled').removeClass('state_init');
          $(el).find('.js-input-field').val(givesAttribute);
        });
      }
      // function showDeliveryBlock() {
      //   formDelivery.deliveryAvailability(data);
      // }

      // if (this.steps.currentStep === 1) {
      //   showDeliveryBlock.apply(this);
      // }

      if (data.success === 'incorrect-code') {
        showSmsError.apply(this);
        return;
      }

      if (!url) {
        if (data.success === true) {
          if (data.skip_steps[0]) {
            setSkipStep.apply(this);
            FormHelper.setStepFront(this);
          } else {
            showSuccessModal.apply(this);
          }
        } else {
          FormHelper.showErrorModal();
        }
        return;
      }

      if (data.success === false) {
        if (data.errors) {
          showInputErrors.apply(this);
        } else {
          FormHelper.showErrorModal();
        }
      } else {
        if (data.logs) {
          const logs = JSON.parse(data.logs);
          console.log('%cВывод логов значений полей списка', 'background-color: yellow; color: black; padding: 2px 4px;');
          console.log('Лог трудового стажа поля input %c%s', 'color: yellow;', logs.input_work_experience_current_year);
          console.log('Лог трудового стажа поля select %c%d', 'color: yellow;', logs.work_experience_current_year);
        }
        callback(data);
      }
      if (data.set_hidden_value) {
        setHiddenFields.apply(this);
      }
      if (data.set_attributes) {
        setAttributes.apply(this);
      }
      if (data.skip_steps) {
        setSkipStep.apply(this);
      }
    }

    addPixelMetric(form, response) {
      const pixelUrl = $(form).data('pixel');
      const pixels = $(form).data('pixel');

      if (!pixels) {
        return;
      }

      pixels.split(',').forEach((pixelUrl) => {
        if (pixelUrl.indexOf('#ORDER_ID#') !== -1 && response.request_id) {
          pixelUrl = pixelUrl.replace('#ORDER_ID#', response.request_id);
        }
        if (pixelUrl) {
          $('head').append(`<img src="${pixelUrl}" width="1"  height="1"/>`);
        }
      });
    }
  }

  return new Form(elem);
};
